#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
main()
{
   inicio: 
   system("cls");
   fflush(stdin);
   int cnpj[12],soma1,soma2,i,erro;
   int parte1,parte2,parte3,dig1;
   int parte5,parte6,parte7,dig2,opc;
   char numeros[12],resp;
   printf("*==================================================================*\n");
   printf("|____________________ VALIDADOR DE CNPJ V. 1.0 ____________________|\n");
   printf("|                                                                  |\n");
   printf("|     Autor: Thiago C. Serrilho                                    |\n");
   printf("|     E-mail: webserrilho@gmail.com                                |\n");
   printf("|     3o. Semestre - Licenciatura em Computacao                    |\n");
   printf("|     Disciplina: Linguagem de Programacao I                       |\n");
   printf("|     Prof. Carlos Acacio                                          |\n");
   printf("*==================================================================*\n\n");
   printf("*========================================*\n");
   printf("|       O que voce deseja fazer?         |\n");
   printf("*----------------------------------------*\n");
   printf("| 1 - Descobrir os digitos verificadores |\n");
   printf("| 2 - Verificar a validade de um CNPJ    |\n");
   printf("| 3 - Finaliza o programa                |\n");
   printf("*========================================*\n");
   erro=0;
   do
   {
      erro++;
      if(erro>1)
      {
         printf("Erro: Opcao invalida!\n");
         erro=1;
      }
      printf("Informe a sua opcao: ");
      scanf("%d",&opc); fflush(stdin);
      printf("*==================================================================*\n");
   }while(opc>3 || opc<1);
   
   switch(opc)
   {
      case 1:
      {
         //*==========================================*
         //|       Leitura dos numeros do CNPJ        |
         //*==========================================*
         printf("Digite os 12 primeiros do CNPJ: ",i);
         for(i=1;i<=12;i++)
         {
            if(i-1==2)printf(".");
            if(i-1==5)printf(".");
            if(i-1==8)printf("/");
            numeros[i]=getche();
            cnpj[i]=atoi(numeros);
            numeros[i]=' '; 
         }
         break;
      }
      case 2:
      {
         printf("Digite os 14 numeros do CNPJ: ",i);
         for(i=1;i<=14;i++)
         {
            if(i-1==2)printf(".");
            if(i-1==5)printf(".");
            if(i-1==8)printf("/");
            if(i-1==12)printf("-");
            numeros[i]=getche();
            cnpj[i]=atoi(numeros);
            numeros[i]=' ';
         }
         break;
      }
      case 3:
      {
         printf("Deseja continuar no programa (s/n)? ");
         scanf("%s",&resp);
         if((resp=='n') || (resp=='N')) goto fim; //termina o programa
         else goto inicio; //volta para o inicio do programa
      }
   }
   //*=========================================*
   //|       Primeiro digito verificador       |
   //*=========================================*
   soma1=((cnpj[1]*5)+
         (cnpj[2]*4)+
         (cnpj[3]*3)+
         (cnpj[4]*2)+
         (cnpj[5]*9)+
         (cnpj[6]*8)+
         (cnpj[7]*7)+
         (cnpj[8]*6)+
         (cnpj[9]*5)+
         (cnpj[10]*4)+
         (cnpj[11]*3)+
         (cnpj[12]*2));
   parte1=int(soma1 / 11);
   parte2=(parte1 * 11);
   parte3=(soma1 - parte2);
   dig1=(11 - parte3);
   if(dig1>9)dig1=0;
   if(opc==1)
   {
      printf("\n*===================================================================*\n");
      printf("Primeiro digito: %d\n",dig1);
   }
   else
   printf("\n*===================================================================*\n");
   //*=========================================*
   //|       Segundo digito verificador        |
   //*=========================================*
   soma2=((cnpj[1]*6)+
         (cnpj[2]*5)+
         (cnpj[3]*4)+
         (cnpj[4]*3)+
         (cnpj[5]*2)+
         (cnpj[6]*9)+
         (cnpj[7]*8)+
         (cnpj[8]*7)+
         (cnpj[9]*6)+
         (cnpj[10]*5)+
         (cnpj[11]*4)+
         (cnpj[12]*3)+
         (dig1*2));
   parte5=int(soma2 / 11);
   parte6=(parte5 * 11);
   parte7=(soma2 - parte6);
   dig2=(11 - parte7);
   if(dig2>9)dig2=0;
   if(opc==1)
   {
      printf("Segundo digito.: %d\n",dig2);
      printf("*==================================================================*\n");
   }
   //*==========================================*
   //|       Impressao do cnpj completo       | 
   //*==========================================*
   printf("Numero completo do CNPJ:\n");
   for(i=1;i<=12;i++)
   {
      printf("%d",cnpj[i]);//numeros do CNPJ
      if(i==2)printf(".");
      if(i==5)printf(".");
      if(i==8)printf("/");
   }
   if(opc==1)
   printf("-%d%d\n",dig1,dig2); //dois �ltimos digitos
   if(opc==2)
   {
      if(cnpj[13]==dig1 && cnpj[14]==dig2)
      {
         printf("-%d%d\n",cnpj[13],cnpj[14]); //dois �ltimos digitos
         printf("CNPJ valido\n");
      }
      else
      {
         printf("-%d%d\n",cnpj[13],cnpj[14]); //dois �ltimos digitos
         printf("CNPJ invalido\n");
      }
   }
   printf("*==================================================================*\n");
   printf("Pressione \"enter\" para continuar...");
   getchar();
   goto inicio; //volta no inicio do programa (n�o usem goto kkk)
   fim:;
}
